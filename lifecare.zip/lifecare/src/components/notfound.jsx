function Notfound(){
    return(
        <div>
            <h1  style={{backgroundColor:'green'}}>Not Found</h1>
        </div>
    )
}
export default Notfound;