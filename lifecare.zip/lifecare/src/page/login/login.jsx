import { Link,useNavigate } from 'react-router-dom';
import React, { useState } from "react";
import axios from 'axios';
import Loading from '../../components/loading';




function Login(props) {
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    let navigate = useNavigate();


    
    

    function handleSubmit(event) {
        event.preventDefault();
        var url ='http://127.0.0.1:8000/api';
        if(!email){ setError('Enter your email') }
        if(!password){setError('Enter your password') }
        if(!email && !password){ setError('Enter your email and password') }

        let formData = new FormData()
        formData.append('email', email)
        formData.append('password', password)
        //console.log(formData);

        if(email && password ) {
            setError(null);
            setLoading(true);
            
            axios.post(url + "/login" , formData)
            .then(res=>{
                if(res.data) {
                    setLoading(false);
                    const arr = res.data.data;
                    localStorage.setItem('token',arr.remember_token);
                    localStorage.setItem('status','login');
                    localStorage.setItem('user', JSON.stringify(res.data.data));
                    navigate('/home');
                    
                   
                }
            })
            .catch(err=>{
                if(err.response){
                    setLoading(false);
                    setError('Wrong email or password');
                } else {
                    setLoading(false);
                    setError('Failed connect server');
                }
                console.log('error');

            })
        }
    }

    return (
        <div>
            <div className="container-scroller">
                <div className="container-fluid page-body-wrapper full-page-wrapper">
                    <div className="row w-100 m-0">
                        <div className="content-wrapper full-page-wrapper d-flex align-items-center auth login-bg">
                            <div className="card col-lg-4 mx-auto">
                                <div className="card-body px-5 py-5">
                                   
                                    <h3 className="card-title text-left mb-3">Login</h3>
                                    <form onSubmit={handleSubmit}>
                                        <div className="form-group">
                                            <label>Username or email *</label>
                                            <input type="text" className="form-control p_input" name='email' value={email}  onChange={(e) => setEmail(e.target.value)}
          />
                                        </div>
                                        <div className="form-group">
                                            <label>Password *</label>
                                            <input type="text" className="form-control p_input" name='password' value={password} onChange={(e) => setPassword(e.target.value)}/>
                                        </div>
                                        <div className="form-group d-flex align-items-center justify-content-between">
                                            <div className="form-check">
                                                <label className="form-check-label">
                                                    <input type="checkbox" className="form-check-input" /> Remember me </label>
                                            </div>
                                            <a href="#" className="forgot-pass">Forgot password</a>
                                        </div>
                                        <div className="text-center">
                                           {error && <><small style={{ color: 'red' }}>{error}</small><br /></>}<br />
                                            <button type="submit" className="btn btn-primary btn-block enter-btn">{loading ? 'Loading...' : 'Login'}</button>
                                        </div>
                                        <div className="d-flex">
                                            <button className="btn btn-facebook mr-2 col">
                                                <i className="mdi mdi-facebook" /> Facebook </button>
                                            <button className="btn btn-google col">
                                                <i className="mdi mdi-google-plus" /> Google plus </button>
                                        </div>
                                        <p className="sign-up">
                                            Don't have an Account?
                                            <Link to="/register">
                                                Sign Up</Link>
                                        </p>
                                    </form>
                                </div>
                            </div>
                        </div>
                        {/* content-wrapper ends */}
                    </div>
                    {/* row ends */}
                </div>
                {/* page-body-wrapper ends */}
            </div>

        </div>
    );
}

export default Login;