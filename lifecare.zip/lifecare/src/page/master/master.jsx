import Footer from "../../components/footer";
import Header from "../../components/header";
import Sidebar from "../../components/sidebar";
import Home from "../home/Home";
function Master() {
    return (
        <div class="container-scroller">
            <Sidebar />
            <div className="container-fluid page-body-wrapper">
                <Header />
                <div className="main-panel">
                    <div className="content-wrapper">
                        <Home />
                    </div>
                    <Footer />
                </div>
            </div>
        </div>
    )
}

export default Master;