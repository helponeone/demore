<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;
use DB;

class ApiAuthController extends Controller
{
    public function register (Request $request) { 
        #dd($request->all());
        $validator = Validator::make($request->all(), [
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users',
            'password' => 'required|string|min:6|confirmed',
        ]);
        if ($validator->fails())
        {
            return response(['status'=>404,'msg'=>$validator->errors()->all()]);
        }
        $request['password'] = Hash::make($request['password']);
        $request['remember_token'] = Str::random(50);
        #DB::table('user')->insert(['name'=>$request->first,'email'=>$request->user]);
        $user = User::create($request->toArray());
        $token = $user->createToken('Laravel Password Grant Client')->accessToken;
        
        return response(['status'=>200,'msg'=>['User created successfully']]);
        
    }

    public function login (Request $request) {

        $validator = Validator::make($request->all(), [
            'email' => 'required|string|email|max:255',
            'password' => 'required|string|min:6',
        ]);
        if ($validator->fails())
        {
            return response(['status'=>404,'msg'=>$validator->errors()->all()]);
        }
        $user = User::where('email', $request->email)->first();
        #$user = DB::table('users')->where('email', $request->email)->get()->toArray();
        if ($user) {
            if (Hash::check($request->password, $user->password)) {
                $token = $user->createToken('Laravel Password Grant Client')->accessToken;
                
                return response(['status'=>200,'msg'=>['Login Success'],'data'=>$user]);
            } else {
                return response(['status'=>404,'msg'=>['Password mismatch']]);
            }
        } else {
            return response(['status'=>404,'msg'=>['User does not exist']]);
        }
    }

    public function logout (Request $request) {
        $user = User::where(['email'=>$request->email,'remember_token'=>$request->token])->first();
        if ($user) {
            return response(['status'=>200,'msg'=>['You have been successfully logged out!']]);
        }
        else{
            return response(['status'=>404,'msg'=>['Something Error']]);
        }

        
    }

    
}
