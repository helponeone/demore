import React, { Component } from 'react';
import { BrowserRouter as Router,Routes, Route, Redirect } from 'react-router-dom';


import Notfound from './components/notfound';
import Form from "./page/form/form";
import Home from "./page/home/Home";
import Login from "./page/login/login";
import Master from './page/master/master';
import Register from "./page/register/register";

function App() {
  let status = localStorage.getItem('status')
  console.log(status);
  return (
    <div>
      <Router>
        <Routes>
          <Route exact path='/' element={< Login />}></Route>
          <Route exact path='/login' element={< Login />}></Route>
          <Route exact path='/register' element={< Register />}></Route>
          <Route exact path='/home' element={< Home />}></Route>
          <Route exact path='/form' element={< Form />}></Route>
          <Route component={Notfound} />
        </Routes>
      </Router>
    </div>
  );
}

export default App;
