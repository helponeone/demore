<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Book;

class AjaxBOOKCRUDController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $books= Book::orderBy('id','desc')->paginate(2);
        $name= 'kishor';
        $last ='ani bhai';
        $arr = array('a'=>10,'b'=>20);

        return view('ajax-book-crud',compact('books','name','last','arr'));
   
        #return view('ajax-book-crud',array('name'=>$name,'books'=>books,'last'=>$last));
    }
    
   
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        // DB::table('book')->insert([
        //     'title' => $request->Tiltl, 
        //     'code' => $request->code,
        //     'author' => $request->author,
        // ]);

        // DB::table('book')->where(['id'=>$request->id])->update( [
        //     'title' => $request->title, 
        //     'code' => $request->code,
        //     'author' => $request->author,
        // ]);

        $book   =   Book::updateOrCreate(
                    [
                        'id' => $request->id
                    ],
                    [
                        'title' => $request->title, 
                        'code' => $request->code,
                        'author' => $request->author,
                    ]);
    
        return response()->json(['success' => true]);
    }
    
    
    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request)
    {   

        #$where = array('id' => $request->id,'email' => $request->email);
        $where = array('id' => $request->id);
        $book  = Book::where($where)->first();
        #$book  = Book::where($where)->limit(10)->orderBy('id','DESC');

 
        return response()->json($book);
    }
 
   
    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request)
    {
        $book = Book::where('id',$request->id)->delete();
        #$book = Book::where(['id' => $request->id,'email' => $request->email])->delete();
   
        return response()->json(['success' => true]);
    }
}