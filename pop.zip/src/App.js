import react from "react";
import Layout from "./layouts/admin/Layout";
import Home from "./components/admin/Home/Home";
import Form from "./components/admin/Form/Form";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Login from "./components/admin/Login/Login";

function App() {
  return (
    <>
      <Router>
        <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/" element={<Layout />}>
            <Route index element={<Home />} />
            <Route path="/form" element={<Form />} />
        </Route>
        <Route path="*" element={<h1>Page Not Found</h1>}/>
        </Routes>
      </Router>
    </>
  );
}

export default App;
