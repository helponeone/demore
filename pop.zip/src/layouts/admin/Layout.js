import react from "react"
import { Outlet } from "react-router-dom";
import Footer from "./Footer";
import Header from "./Header";
import Sidebar from "./Sidebar";
const Layout = () => {
    return (
        <div className="wrapper hold-transition skin-blue sidebar-mini">
        <Header />
        <Sidebar />
        <div className="content-wrapper">
        <Outlet />
        </div>
        <Footer />
        <div className="control-sidebar-bg"></div>
        </div>
    )
}
export default Layout