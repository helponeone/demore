import react from "react"
import { Link } from "react-router-dom";
const Sidebar = () => {
    return (
        <>
            <aside className="main-sidebar">
                <section className="sidebar">
                    <div className="user-panel">
                        <div className="pull-left image">
                            <img src="assets/admin/dist/img/user2-160x160.jpg" className="img-circle" alt="User Image" />
                        </div>
                        <div className="pull-left info">
                            <p>Test</p>
                            <a href="#"><i className="fa fa-circle text-success" /> Online</a>
                        </div>
                    </div>
                    
                    <ul className="sidebar-menu" data-widget="tree">
                        <li className="header">MAIN NAVIGATION</li>
                        <li className="active treeview">
                            <a href="#">
                                <i className="fa fa-dashboard" /> <span>Dashboard</span>
                                <span className="pull-right-container">
                                    <i className="fa fa-angle-left pull-right" />
                                </span>
                            </a>
                            <ul className="treeview-menu">
                                <li className="active"><Link to="/"><i className="fa fa-circle-o" /> Home</Link></li>
                                <li><Link to="/form"><i className="fa fa-circle-o" /> Form</Link></li>
                            </ul>
                        </li>
                    </ul>
                </section>
            </aside>

        </>
    )
}
export default Sidebar