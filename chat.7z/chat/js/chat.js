console.log('chat.js file loaded!')

// IMPORTANT! By default, socket.io() connects to the host that
// served the page, so we dont have to pass the server url
var url = "http://localhost:3000";
var io = io.connect(url)
var username = "";
function setUsername() {
    username = $("#username").val();
    $("#send-message").show();
    io.emit("new_user", username);
    // $.ajax({
    // 	url: url + "/get_messages",
    // 	method: "GET",
    // 	success: function (response) {
    // 		response = JSON.parse(response);
    // 		var messages = document.getElementById("messages");

    // 		for (var a = 0; a < response.length; a++) {
    // 			var li = document.createElement("li");
    // 			li.id = "message-" + response[a].id;

    // 			if (response[a].username == "") {
    // 				li.innerHTML = response[a].message;
    // 			} else {
    // 				li.innerHTML = "<b>" + response[a].username + ":</b> " + response[a].message;
    // 			}
                
    // 			if (response[a].username == username) {
    // 				li.innerHTML += "<button class='btn-delete' data-id=" + response[a].id + " onclick='deleteMessage(this);'>Delete</button>";
    // 			}

    // 			messages.appendChild(li);
    // 		}

    // 		io.emit("new_user", username);
    // 	}
    // });

    // return false;
}

function sendMessage(form) {
    var message = form.message.value;
    io.emit("new_message", {
        message: message,
        username: username
    });
    form.message.value = "";

    return false;
}

function deleteMessage(self) {
    var id = self.getAttribute("data-id");
    io.emit("delete_message", id);
}

io.on("delete_message", function (id) {
    document.getElementById("message-" + id).innerHTML = "<i>Message has been deleted</i>";
});

io.on("new_message", function (data) {
    var messages = document.getElementById("messages");
    var li = document.createElement("li");
    li.id = "message-" + data.id;

    if (data.username == "") {
        li.innerHTML = data.message;
    } else {
        li.innerHTML = "<b>" + data.username + ":</b> " + data.message;
    }

    if (data.username == username) {
        li.innerHTML += "<button class='btn-delete' data-id=" + data.id + " onclick='deleteMessage(this);'>Delete</button>";
    }

    messages.appendChild(li);
});

io.on("new_user", function (username) {
    console.log('.........................');
    var messages = document.getElementById("messages");
    var li = document.createElement("li");
    li.innerHTML = "<b>" + username + "</b> just joined the chat";
    messages.appendChild(li);
});