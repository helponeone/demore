var cors = require('cors')

var express = require("express");
var app = express();

var bodyParser = require("body-parser");
//app.use(bodyParser.urlencoded());
//app.use(bodyParser.json());

app.use(express.urlencoded({extended: true})); 
app.use(express.json());   

var http = require("http").createServer(app);
var io = require("socket.io")(http,{
  cors: {
    origin: "http://localhost",
    methods: ["GET", "POST"]
  }
});

var mysql = require("mysql");
var connection = mysql.createConnection({
	"host": "localhost",
	"user": "root",
	"password": "",
	"database": "web_chat"
});
app.use(cors())

app.use(function (req, res, next) {
    res.setHeader('Access-Control-Allow-Origin', '*');
    next();
});
// app.use("/js", express.static('./js/'));

// app.get("/", function (req, res) {
//   // result.end("Hello world !");
//   res.sendFile(__dirname + '/index.html');


// });
app.get("/get_messages", function (request, res) {
  connection.query("SELECT * FROM messages", function (error, results) {
    if (error) throw error;
    res.end(JSON.stringify(results));
  });
});
connection.connect(function (error) {
  if (error) throw error;
  console.log("MySql Connected");



	io.on("connection", function (socket) {
		 console.log("socket connected");

		socket.on("new_user", function (username) {
			connection.query("SELECT * FROM users WHERE username = '" + username + "'", function (error,results) {
        console.log('yes',results.length);
				if (results.length < 1) {
					connection.query("INSERT INTO users(username) VALUES('" + username + "')", function (error, result) {
            console.log(result);
						io.emit("new_user", username);
					});
				} else {
					io.emit("new_user", username);
				}
			});
		});

		socket.on("delete_message", function (id) {
			connection.query("DELETE FROM messages WHERE id = '" + id + "'", function (error, result) {
				io.emit("delete_message", id);
			});
		})

		socket.on("new_message", function (data) {
			connection.query("INSERT INTO messages(username, message) VALUES('" + data.username + "', '" + data.message + "')", function (error, result) {
				data.id = result.insertId;
				io.emit("new_message", data);
			});
		});
	});
});

http.listen(3000, function () {
	console.log("Listening :3000");
});