<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Chat app</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<script src="js/jquery.js"></script>
    <!-- load Socket.io library -->
    <script
      src="https://cdnjs.cloudflare.com/ajax/libs/socket.io/3.1.1/socket.io.js"
      integrity="sha512-oFOCo2/3DtjrJG4N27BjSLQWoiBv171sK6a+JiWjp/7agxC2nCUP358AqzxkBUb5jX8g6CYLPdSKQTbC0weCwA=="
      crossorigin="anonymous"
    ></script>
    <!-- Script to emit/receive events from socket.io server -->
    <script defer src="js/chat.js"></script>
  </head>
  <body>
    <h1>It works!</h1>
	<form onsubmit="setUsername();" id="form-login">
		<div class="form-group">
			<input type="text" autocomplete="off" id="username" placeholder="Enter username">
		</div>
	
		<div class="form-group">
			<input type="submit" value="Select">
		</div>
	</form>
	
	<div id="chat-box">
		<div id="all-chats">
			<ul id="messages" style="max-height: 1150px; overflow: scroll;"></ul>
		</div>
	
		<div id="send-message" style="display: none;">
			<form onsubmit="sendMessage(this);">
				<div class="form-group">
					<input type="text" autocomplete="off" name="message" id="message" placeholder="Enter message">
				</div>
	
				<div class="form-group">
					<input type="submit" value="Send">
				</div>
			</form>
		</div>
	</div>
  </body>
</html>

<!-- <script>
		var url = "http://localhost:3000";
		var io = io(url);
	    var username = "";

	
</script> -->